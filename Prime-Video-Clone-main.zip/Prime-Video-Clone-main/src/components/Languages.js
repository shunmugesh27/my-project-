const abc = [
  { id: 0, name: "Hindi" },
  { id: 1, name: "English" },
  { id: 2, name: "Telgu" },
  { id: 3, name: "Tamil" },
  { id: 4, name: "Malyalam" },
  { id: 5, name: "Kannada" },
  { id: 6, name: "Marathi" },
  { id: 7, name: "Punjabi" },
  { id: 8, name: "Gujarati" },
  { id: 9, name: "Bengali" },
];

export default abc;
